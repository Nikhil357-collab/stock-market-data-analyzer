def generate_report(summary, ticker):

    report_path = "reports\\final_stock_report.txt"

    with open(report_path, "w") as file:

        file.write("STOCK MARKET DATA ANALYZER REPORT\n")
        file.write("=" * 50 + "\n\n")

        file.write(f"Ticker: {ticker}\n\n")

        for key, value in summary.items():
            file.write(f"{key}: {value}\n")

    print(f"Report saved to {report_path}")