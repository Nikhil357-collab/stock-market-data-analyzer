def analyze_stock(df):

    highest_price = df["High"].max()
    lowest_price = df["Low"].min()

    avg_close = df["Close"].mean()

    volatility = df["Volatility"].mean()

    total_return = (
        (df["Close"].iloc[-1] - df["Close"].iloc[0])
        / df["Close"].iloc[0]
    ) * 100

    trend = "Bullish"

    if df["SMA_20"].iloc[-1] < df["SMA_50"].iloc[-1]:
        trend = "Bearish"

    summary = {
        "Highest Price": round(highest_price, 2),
        "Lowest Price": round(lowest_price, 2),
        "Average Close": round(avg_close, 2),
        "Average Volatility": round(volatility, 4),
        "Total Return (%)": round(total_return, 2),
        "Trend": trend
    }

    return summary