import yfinance as yf
import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np
import joblib

# DOWNLOAD DATA
df = yf.download("AAPL", period="2y")

# PREPARE DATA
df["Prediction"] = df["Close"].shift(-1)

df = df.dropna()

X = np.array(df["Close"]).reshape(-1, 1)

y = np.array(df["Prediction"])

# TRAIN MODEL
model = LinearRegression()

model.fit(X, y)

# SAVE MODEL
joblib.dump(model, "model.pkl")

print("AI Model Trained Successfully!")