from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

# LOAD MODEL
model = joblib.load("model.pkl")

# CREATE API
app = FastAPI(
    title="Stock Prediction API",
    description="AI Stock Price Prediction System",
    version="1.0"
)

# REQUEST MODEL
class StockRequest(BaseModel):
    price: float

# ROOT ENDPOINT
@app.get("/")
def home():
    return {
        "message": "Stock Prediction API Running"
    }

# PREDICTION ENDPOINT
@app.post("/predict")
def predict(data: StockRequest):

    prediction = model.predict(
        np.array([[data.price]])
    )

    return {
        "current_price": data.price,
        "prediction": float(prediction[0])
    }