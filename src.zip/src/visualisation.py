import matplotlib.pyplot as plt
import seaborn as sns

def create_visualizations(df, ticker):

    # PRICE + MOVING AVERAGES
    plt.figure(figsize=(14, 7))

    plt.plot(df["Close"], label="Close Price")

    plt.plot(df["SMA_20"], label="20-Day SMA")

    plt.plot(df["SMA_50"], label="50-Day SMA")

    plt.title(f"{ticker} Stock Price Analysis")

    plt.xlabel("Date")
    plt.ylabel("Price")

    plt.legend()

    plt.savefig("outputs/moving_average_chart.png")

    plt.close()

    # RETURN DISTRIBUTION
    plt.figure(figsize=(10, 5))

    sns.histplot(df["Daily Return"].dropna(), bins=50)

    plt.title("Daily Return Distribution")

    plt.savefig("outputs/return_distribution.png")

    plt.close()

    print("Charts saved successfully!")