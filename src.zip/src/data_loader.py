import yfinance as yf
import pandas as pd

def fetch_stock_data(ticker, start_date, end_date):

    try:
        print(f"Fetching data for {ticker}...")

        df = yf.download(
            ticker,
            start=start_date,
            end=end_date
        )

        # CSV FALLBACK
        if df.empty:
            print("API failed. Loading local CSV...")
            df = pd.read_csv("data/sample_stock_data.csv")

        return df

    except Exception as e:
        print("Error:", e)

        print("Loading CSV fallback...")
        df = pd.read_csv("data/sample_stock_data.csv")

        return df
    