import pandas as pd

def add_indicators(df):

    # Daily Returns
    df["Daily Return"] = df["Close"].pct_change()

    # Moving Averages
    df["SMA_20"] = df["Close"].rolling(window=20).mean()

    df["SMA_50"] = df["Close"].rolling(window=50).mean()

    # Volatility
    df["Volatility"] = df["Daily Return"].rolling(window=20).std()

    return df