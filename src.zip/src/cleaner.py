def clean_data(df):

    # Remove duplicate rows
    df = df.drop_duplicates()

    # Handle missing values
    df = df.dropna()

    # Convert index to datetime
    df.index = df.index.astype("datetime64[ns]")

    # Sort values
    df = df.sort_index()

    return df